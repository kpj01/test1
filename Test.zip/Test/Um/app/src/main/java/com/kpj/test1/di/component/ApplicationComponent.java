package com.kpj.test1.di.component;


import com.kpj.test1.di.module.ApplicationModule;
import com.example.valeriya.recylceviewdemo.di.scope.ApplicationScope;

import dagger.Component;

@ApplicationScope
@Component(modules = ApplicationModule.class)
public interface ApplicationComponent {

}
