package com.kpj.test1.network;





import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;

import retrofit2.Call;

public interface ServiceApiHelper {


    Call<MainResponse> getData(int memberCount);
}
