package com.kpj.test1.network;




import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;

import javax.inject.Inject;

import retrofit2.Call;

public class DataManager implements DataHelper {
    private ServiceApi serviceApi;

    @Inject
    public DataManager(ApiClient apiClient) {

        serviceApi = apiClient.getServiceApi();
    }

    @Override
    public Call<MainResponse> getData(int memberCount) {
        return serviceApi.getData(memberCount);
    }
}
