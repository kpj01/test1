package com.kpj.test1.ui.main.recycleviewer;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.kpj.test1.R;

public class RecycleViewHolder extends RecyclerView.ViewHolder {

    TextView tvPlanName, tvPlanCost, tvFooter1, tvFooter2, tvSave;
    TextView tvBenefitTitle1, tvBenefitSubTitle1, tvBenefitTitle2, tvBenefitSubTitle2, tvBenefitTitle3, tvBenefitSubTitle3, tvBenefitTitle4, tvBenefitSubTitle4, tvBenefitTitle5, tvBenefitSubTitle5;

    RecycleViewHolder(@NonNull View itemView) {
        super(itemView);
        tvBenefitTitle1 = itemView.findViewById(R.id.tv_benefit_title1);
        tvBenefitSubTitle1 = itemView.findViewById(R.id.tv_benefit_subtitle1);

        tvBenefitTitle2 = itemView.findViewById(R.id.tv_benefit_title2);
        tvBenefitSubTitle2 = itemView.findViewById(R.id.tv_benefit_subtitle2);

        tvBenefitTitle3 = itemView.findViewById(R.id.tv_benefit_title3);
        tvBenefitSubTitle3 = itemView.findViewById(R.id.tv_benefit_subtitle3);

        tvBenefitTitle4 = itemView.findViewById(R.id.tv_benefit_title4);
        tvBenefitSubTitle4 = itemView.findViewById(R.id.tv_benefit_subtitle4);

        tvBenefitTitle5 = itemView.findViewById(R.id.tv_benefit_title5);
        tvBenefitSubTitle5 = itemView.findViewById(R.id.tv_benefit_subtitle5);
        tvSave = itemView.findViewById(R.id.tv_save);

        tvFooter1 = itemView.findViewById(R.id.tv_footer1);
        tvFooter2 = itemView.findViewById(R.id.tv_footer2);
        tvPlanName = itemView.findViewById(R.id.tv_plan_name);
        tvPlanCost = itemView.findViewById(R.id.tv_plan_cost);
    }

}
