package com.kpj.test1.network.ResponsePojo.homeResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Benefit {

    @SerializedName("benefit_title")
    @Expose
    private String benefitTitle;
    @SerializedName("benefit_sub_title")
    @Expose
    private String benefitSubTitle;
    @SerializedName("benefit_icon_network")
    @Expose
    private String benefitIconNetwork;
    @SerializedName("benefit_icon_local")
    @Expose
    private String benefitIconLocal;
    @SerializedName("benefit_icon")
    @Expose
    private String benefitIcon;

    public String getBenefitTitle() {
        return benefitTitle;
    }

    public void setBenefitTitle(String benefitTitle) {
        this.benefitTitle = benefitTitle;
    }

    public String getBenefitSubTitle() {
        return benefitSubTitle;
    }

    public void setBenefitSubTitle(String benefitSubTitle) {
        this.benefitSubTitle = benefitSubTitle;
    }

    public String getBenefitIconNetwork() {
        return benefitIconNetwork;
    }

    public void setBenefitIconNetwork(String benefitIconNetwork) {
        this.benefitIconNetwork = benefitIconNetwork;
    }

    public String getBenefitIconLocal() {
        return benefitIconLocal;
    }

    public void setBenefitIconLocal(String benefitIconLocal) {
        this.benefitIconLocal = benefitIconLocal;
    }

    public String getBenefitIcon() {
        return benefitIcon;
    }

    public void setBenefitIcon(String benefitIcon) {
        this.benefitIcon = benefitIcon;
    }

}
