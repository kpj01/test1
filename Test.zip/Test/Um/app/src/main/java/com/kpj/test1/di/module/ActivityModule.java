package com.kpj.test1.di.module;




import android.app.ProgressDialog;
import android.content.Context;

import com.example.valeriya.recylceviewdemo.di.qualifier.Activityq;

import dagger.Module;
import dagger.Provides;

@Module(includes = NetworkModule.class)
public class ActivityModule {


    @Provides
    ProgressDialog provideProgressDialog(@Activityq Context context){

        return new ProgressDialog(context);
    }

}
