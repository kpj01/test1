package com.kpj.test1.network;

import com.example.valeriya.recylceviewdemo.di.scope.ActivityScope;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@ActivityScope
public class ApiClient {


    private ServiceApi serviceApi;

    public ServiceApi getServiceApi() {
        return serviceApi;
    }


    @Inject
    public ApiClient(OkHttpClient.Builder okHttpClient, NetworkInterceptor interceptor, Retrofit.Builder retroBuilder) {


        okHttpClient.connectTimeout(30_000, TimeUnit.MILLISECONDS);
        okHttpClient.readTimeout(30_000, TimeUnit.MILLISECONDS);
        okHttpClient.writeTimeout(30_000, TimeUnit.MILLISECONDS);
        okHttpClient.addInterceptor(interceptor);


        serviceApi = retroBuilder.baseUrl("http://demo4929648.mockable.io/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient.build()).build().create(ServiceApi.class);


    }

}
