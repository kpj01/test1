package com.kpj.test1.di.module;
import com.kpj.test1.network.DataHelper;
import com.kpj.test1.network.DataManager;
import com.kpj.test1.network.NetworkInterceptor;
import com.example.valeriya.recylceviewdemo.di.scope.ActivityScope;


import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

@Module(includes = ContextModule.class)
public class NetworkModule {


    @Provides
    @ActivityScope
    OkHttpClient.Builder provideBuilder() {
        return new OkHttpClient.Builder();
    }

    @Provides
    @ActivityScope
    Retrofit.Builder provideRetrofitBuild() {
        return  new Retrofit.Builder();
    }

    @Provides
    @ActivityScope
    NetworkInterceptor providesNetworkInterceptor(){
        return  new NetworkInterceptor();
    }


    @Provides
    @ActivityScope
    DataHelper providesDataHelper(DataManager dataManager){
        return dataManager;
    }
}
