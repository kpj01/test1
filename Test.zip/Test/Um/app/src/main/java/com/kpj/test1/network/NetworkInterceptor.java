package com.kpj.test1.network;


import android.util.Log;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

public class NetworkInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request original = chain.request();
        Request.Builder requestBuilder = original.newBuilder();

        Request request = requestBuilder.build();


        if (request.url() != null) {
            Log.d("request URL ::", request.url().toString());
        }
        if (request.headers() != null) {
            Log.d("request headers ::", request.headers().toMultimap().toString());
        }
        if (request.body() != null) {
            Log.d("request Body ::", bodyToString(request));
        }
        Response response = chain.proceed(request);
        String body = response.body().string();
        MediaType content = response.body().contentType();
        try {
            Log.d("response Code ::", String.valueOf(response.code()));
            if (response.body() != null) {
                Log.d("response Body ::",body);
            }

        } catch (Exception e) {
            Log.d("NetworkInterceptor", e.getMessage());
        }
        return response.newBuilder().body(ResponseBody.create(content, body)).build();
    }
    private static String bodyToString(final Request request) {
        try {
            final Request copy = request.newBuilder().build();
            final Buffer buffer = new Buffer();
            copy.body().writeTo(buffer);
            return buffer.readUtf8();
        } catch (Exception e) {
            return "did not work";
        }
    }
}
