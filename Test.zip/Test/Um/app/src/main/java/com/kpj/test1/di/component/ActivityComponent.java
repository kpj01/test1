package com.kpj.test1.di.component;


import com.kpj.test1.ui.main.MainActivity;
import com.kpj.test1.di.module.ActivityModule;
import com.example.valeriya.recylceviewdemo.di.scope.ActivityScope;


import dagger.Component;
import okhttp3.OkHttpClient;

@ActivityScope
@Component(dependencies = ApplicationComponent.class, modules = ActivityModule.class)
public interface ActivityComponent {

void Inject(MainActivity activity);


    @ActivityScope
    OkHttpClient.Builder getOkHttpClient();

}
