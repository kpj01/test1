package com.kpj.test1.network.ResponsePojo.homeResponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Plan {


    @SerializedName("plan_name")
    @Expose
    private String planName;
    @SerializedName("plan_cost")
    @Expose
    private Integer planCost;
    @SerializedName("plan_disc_cost")
    @Expose
    private Integer planDiscCost;
    @SerializedName("plan_save_upto")
    @Expose
    private Integer planSaveUpto;
    @SerializedName("benefits")
    @Expose
    private List<Benefit> benefits = null;

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public Integer getPlanCost() {
        return planCost;
    }

    public void setPlanCost(Integer planCost) {
        this.planCost = planCost;
    }

    public Integer getPlanDiscCost() {
        return planDiscCost;
    }

    public void setPlanDiscCost(Integer planDiscCost) {
        this.planDiscCost = planDiscCost;
    }

    public Integer getPlanSaveUpto() {
        return planSaveUpto;
    }

    public void setPlanSaveUpto(Integer planSaveUpto) {
        this.planSaveUpto = planSaveUpto;
    }

    public List<Benefit> getBenefits() {
        return benefits;
    }

    public void setBenefits(List<Benefit> benefits) {
        this.benefits = benefits;
    }

}
