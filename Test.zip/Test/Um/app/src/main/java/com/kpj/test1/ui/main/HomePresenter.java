package com.kpj.test1.ui.main;


import android.support.annotation.NonNull;
import android.util.Log;


import com.kpj.test1.base.BasePresenter;
import com.kpj.test1.network.DataHelper;
import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomePresenter<V extends HomeMVP.View> extends BasePresenter<V> implements HomeMVP.Presenter<V> {


    @Inject
    public HomePresenter(DataHelper dataHelper) {
        super(dataHelper);

    }


     void initialData(int memberCount) {


        getBase().showLoading();
        Call<MainResponse> stringCall = getDataHelper().getData(memberCount);


        stringCall.enqueue(new Callback<MainResponse>() {
            @Override
            public void onResponse(@NonNull Call<MainResponse> call, @NonNull Response<MainResponse> response) {
                getBase().hideLoading();
                if (response.isSuccessful()) {
                    getBase().Result(response.body());
                } else {
                    getBase().showToast("Error getting data, tray again");
                }
            }

            @Override
            public void onFailure(@NonNull Call<MainResponse> call,@NonNull  Throwable t) {
                getBase().hideLoading();
                getBase().showToast("Error getting data, tray again");
                Log.d("data",t.getMessage());
            }
        });


    }

}
