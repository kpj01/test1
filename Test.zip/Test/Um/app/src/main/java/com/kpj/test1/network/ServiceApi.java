package com.kpj.test1.network;




import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ServiceApi {

    @GET("/IHOPolicyDetails")
    Call<MainResponse> getData(@Query("member_count") int memberCount);
}
