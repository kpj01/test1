package com.kpj.test1.base;


import com.kpj.test1.network.DataHelper;

public class BasePresenter<V extends BaseMVP.View> implements BaseMVP.Presenter<V> {

    private DataHelper dataHelper;


    private V base;


    public BasePresenter(DataHelper dataHelper) {
        this.dataHelper = dataHelper;
    }

    @Override
    public void attach(V view) {
        base = view;
    }

    @Override
    public void detach() {
        base = null;
    }

    public DataHelper getDataHelper() {
        return dataHelper;
    }

    public V getBase() {
        return base;
    }
}
