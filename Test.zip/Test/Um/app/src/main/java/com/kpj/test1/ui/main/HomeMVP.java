package com.kpj.test1.ui.main;


import com.kpj.test1.base.BaseMVP;
import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;

public class HomeMVP {


    interface View extends BaseMVP.View {

        void Result(MainResponse homeResponse);

    }

    interface Presenter<V extends BaseMVP.View> extends BaseMVP.Presenter<V>{


    }
}
