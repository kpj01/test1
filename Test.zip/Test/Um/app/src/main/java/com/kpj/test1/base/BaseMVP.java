package com.kpj.test1.base;
public class BaseMVP {

    public interface View {
        void showLoading();

        void hideLoading();

        void showToast(String message);
    }


    public interface Presenter<V extends View> {
        void attach(V view);

        void detach();

    }

}

