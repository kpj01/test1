package com.kpj.test1.di.module;

import dagger.Module;

@Module
public class ApplicationModule {
}
