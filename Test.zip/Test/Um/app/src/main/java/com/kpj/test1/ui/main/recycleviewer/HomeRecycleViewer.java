package com.kpj.test1.ui.main.recycleviewer;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.kpj.test1.R;
import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;
import com.kpj.test1.network.ResponsePojo.homeResponse.Plan;

import java.util.Locale;

public class HomeRecycleViewer extends RecyclerView.Adapter<RecycleViewHolder> {
    private MainResponse mainResponse;
   private Context context;

    public HomeRecycleViewer(MainResponse mainResponse) {
        this.mainResponse = mainResponse;
    }

    @NonNull
    @Override
    public RecycleViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        context = viewGroup.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(context);

        View view = layoutInflater.inflate(R.layout.data_item, viewGroup, false);

        return new RecycleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecycleViewHolder recycleViewHolder, int i) {
        Plan plan = mainResponse.getPlans().get(i);
        try {
            recycleViewHolder.tvPlanName.setText(String.format("%s", plan.getPlanName()));
            recycleViewHolder.tvPlanCost.setText(String.format(Locale.getDefault(), "₹ %d", plan.getPlanCost()));

            recycleViewHolder.tvBenefitTitle1.setText(String.format("%s", plan.getBenefits().get(0).getBenefitTitle()));
            recycleViewHolder.tvBenefitSubTitle1.setText(String.format("%s", plan.getBenefits().get(0).getBenefitSubTitle()));

            recycleViewHolder.tvBenefitTitle2.setText(String.format("%s", plan.getBenefits().get(1).getBenefitTitle()));
            recycleViewHolder.tvBenefitSubTitle2.setText(String.format("%s", plan.getBenefits().get(1).getBenefitSubTitle()));

            recycleViewHolder.tvBenefitTitle3.setText(String.format("%s", plan.getBenefits().get(2).getBenefitTitle()));
            recycleViewHolder.tvBenefitSubTitle3.setText(String.format("%s", plan.getBenefits().get(2).getBenefitSubTitle()));

            recycleViewHolder.tvBenefitTitle4.setText(String.format("%s", plan.getBenefits().get(3).getBenefitTitle()));
            recycleViewHolder.tvBenefitSubTitle4.setText(String.format("%s", plan.getBenefits().get(3).getBenefitSubTitle()));

            recycleViewHolder.tvBenefitTitle5.setText(String.format("%s", plan.getBenefits().get(4).getBenefitTitle()));
            recycleViewHolder.tvBenefitSubTitle5.setText(String.format("%s", plan.getBenefits().get(4).getBenefitSubTitle()));



            recycleViewHolder.tvFooter1.setText(String.format(Locale.getDefault(),"Buy Now for %d", plan.getPlanCost()));
            recycleViewHolder.tvFooter2.setText(String.format(Locale.getDefault(),"Buy Now for %d", plan.getPlanCost()));
            recycleViewHolder.tvSave.setText(String.format(Locale.getDefault(),"Save Upto Rs. %d", plan.getPlanSaveUpto()));
        } catch (Exception e) {
            Toast.makeText(context, "Unable to load data correctly", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return mainResponse.getPlans().size();
    }
}
