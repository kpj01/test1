package com.kpj.test1.di.module;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.example.valeriya.recylceviewdemo.di.scope.ActivityScope;

import dagger.Module;
import dagger.Provides;

@Module
public class ContextModule {

    private AppCompatActivity activity;

    public ContextModule(AppCompatActivity activity) {
        this.activity = activity;
    }

    @Provides
    @ActivityScope
    @com.example.valeriya.recylceviewdemo.di.qualifier.Activityq
    public AppCompatActivity providesActivity(){
        return activity;
    }

    @Provides
    @ActivityScope
    @com.example.valeriya.recylceviewdemo.di.qualifier.Activityq
    public  Context providesContext(){
        return activity;
    }





}
