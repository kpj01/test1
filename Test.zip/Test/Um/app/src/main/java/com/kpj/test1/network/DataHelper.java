package com.kpj.test1.network;


public interface DataHelper extends ServiceApiHelper {
}
