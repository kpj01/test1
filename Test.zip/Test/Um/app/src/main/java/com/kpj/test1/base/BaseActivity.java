package com.kpj.test1.base;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.kpj.test1.di.component.ActivityComponent;
import com.kpj.test1.di.component.DaggerActivityComponent;
import com.kpj.test1.di.module.ContextModule;


public class BaseActivity extends AppCompatActivity implements BaseMVP.View {
    ActivityComponent activityComponent;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    @Override
    public void showLoading() {

    }

    @Override
    public void hideLoading() {

    }

    @Override
    public void showToast(String message) {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }


    public ActivityComponent getActivityComponent() {
        return   activityComponent = DaggerActivityComponent.builder().contextModule(new ContextModule(this)).build();
    }
}
