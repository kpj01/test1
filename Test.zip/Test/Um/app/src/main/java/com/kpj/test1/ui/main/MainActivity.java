package com.kpj.test1.ui.main;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.kpj.test1.R;
import com.kpj.test1.base.BaseActivity;
import com.kpj.test1.network.ResponsePojo.homeResponse.MainResponse;
import com.kpj.test1.ui.main.recycleviewer.HomeRecycleViewer;

import javax.inject.Inject;

public class MainActivity extends BaseActivity implements HomeMVP.View {
    @Inject
    HomePresenter<HomeMVP.View> homePresenter;
    RecyclerView rvHomeData;
    @Inject
    ProgressDialog progressDialog;

    RadioGroup radioGroup;
    RadioButton rb_two;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getActivityComponent().Inject(this);
        rvHomeData = findViewById(R.id.rv_home_data);
        radioGroup = findViewById(R.id.rg_main);
        rb_two = findViewById(R.id.rb_two_member);
        homePresenter.attach(this);

        //  homePresenter.initialData(2);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId) {
                    case R.id.rb_two_member: {
                        homePresenter.initialData(2);
                        break;
                    }

                    case R.id.rb_four_member: {
                        homePresenter.initialData(4);
                        break;
                    }
                    default: {
                        Log.d("Radio Button", "Error occurred");
                        break;
                    }
                }
            }
        });
        rb_two.setChecked(true);
    }


    @Override
    public void Result(MainResponse homeResponse) {
        HomeRecycleViewer homeRecycleViewer = new HomeRecycleViewer(homeResponse);

        rvHomeData.setAdapter(homeRecycleViewer);

    }


    @Override
    public void showLoading() {
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);

        progressDialog.show();
    }

    @Override
    public void hideLoading() {

        if (progressDialog != null) {

            progressDialog.dismiss();
        }

    }
}
